package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SearchFlightsServlet")
public class SearchFlightsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1"; // replace with your own password

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String tripType = request.getParameter("tripType"); // oneway or roundtrip
        String source = request.getParameter("source");
        String destination = request.getParameter("destination");
        String departureDate = request.getParameter("flightDate");
        String returnDate = request.getParameter("returnDate"); // may be null
        String flexible = request.getParameter("flexible");

        String sortBy = request.getParameter("sortBy");
        String filterAirline = request.getParameter("filterAirline");
        String maxPrice = request.getParameter("maxPrice");
        String minTime = request.getParameter("minTime");

        ArrayList<String[]> flights = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Build dynamic query for departure flights
            StringBuilder depQuery = new StringBuilder("SELECT * FROM flights WHERE source_airport=? AND destination_airport=?");

            if (flexible != null) {
                depQuery.append(" AND DATE(departure_time) BETWEEN DATE_SUB(?, INTERVAL 3 DAY) AND DATE_ADD(?, INTERVAL 3 DAY)");
            } else {
                depQuery.append(" AND DATE(departure_time)=?");
            }

            if (filterAirline != null && !filterAirline.isEmpty()) {
                depQuery.append(" AND airline LIKE ?");
            }
            if (maxPrice != null && !maxPrice.isEmpty()) {
                depQuery.append(" AND price <= ?");
            }
            if (minTime != null && !minTime.isEmpty()) {
                depQuery.append(" AND TIME(departure_time) >= ?");
            }
            if (sortBy != null && !sortBy.isEmpty()) {
                depQuery.append(" ORDER BY ").append(sortBy);
            }

            // Create PreparedStatement with correct ordering
            PreparedStatement depStmt = conn.prepareStatement(depQuery.toString());
            int i = 1;
            depStmt.setString(i++, source);
            depStmt.setString(i++, destination);
            depStmt.setString(i++, departureDate);
            if (flexible != null) depStmt.setString(i++, departureDate);
            if (filterAirline != null && !filterAirline.isEmpty()) depStmt.setString(i++, "%" + filterAirline + "%");
            if (maxPrice != null && !maxPrice.isEmpty()) depStmt.setDouble(i++, Double.parseDouble(maxPrice));
            if (minTime != null && !minTime.isEmpty()) depStmt.setString(i++, minTime);

            ResultSet rs = depStmt.executeQuery();
            while (rs.next()) {
                String[] flight = new String[7]; // ← FIXED: make room for ID
                flight[0] = rs.getString("flight_number");
                flight[1] = rs.getString("departure_time");
                flight[2] = rs.getString("arrival_time");
                flight[3] = rs.getString("airline");
                flight[4] = rs.getString("price");
                flight[5] = "Departure";
                flight[6] = rs.getString("id"); // ← FIXED: assuming your table has an "id" column
                flights.add(flight);
            }
            rs.close();
            depStmt.close();

            // Round-trip logic (optional: can duplicate filter logic if needed)
            if ("roundtrip".equals(tripType) && returnDate != null && !returnDate.isEmpty()) {
                String returnQuery = flexible != null
                        ? "SELECT * FROM flights WHERE source_airport=? AND destination_airport=? AND DATE(departure_time) BETWEEN DATE_SUB(?, INTERVAL 3 DAY) AND DATE_ADD(?, INTERVAL 3 DAY)"
                        : "SELECT * FROM flights WHERE source_airport=? AND destination_airport=? AND DATE(departure_time)=?";

                PreparedStatement returnStmt = conn.prepareStatement(returnQuery);
                returnStmt.setString(1, destination);
                returnStmt.setString(2, source);
                returnStmt.setString(3, returnDate);
                if (flexible != null) returnStmt.setString(4, returnDate);

                ResultSet returnRs = returnStmt.executeQuery();
                while (returnRs.next()) {
                    String[] flight = new String[7]; // ← FIXED
                    flight[0] = returnRs.getString("flight_number");
                    flight[1] = returnRs.getString("departure_time");
                    flight[2] = returnRs.getString("arrival_time");
                    flight[3] = returnRs.getString("airline");
                    flight[4] = returnRs.getString("price");
                    flight[5] = "Return";
                    flight[6] = returnRs.getString("id"); // ← FIXED
                    flights.add(flight);
                }

                returnRs.close();
                returnStmt.close();
            }

            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("flights", flights);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/flightResults.jsp");
        dispatcher.forward(request, response);
    }
}
