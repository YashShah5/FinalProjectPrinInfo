package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/BookFlightServlet")
public class BookFlightServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1"; // your actual MySQL password

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        // Get user session
        HttpSession session = request.getSession(false);
        Integer userId = (Integer) session.getAttribute("userId");

        // Not logged in
        if (userId == null) {
            response.sendRedirect("jsp/login.jsp");
            return;
        }

        String flightId = request.getParameter("flightId");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "INSERT INTO reservations (user_id, flight_id, class_type, status) VALUES (?, ?, 'economy', 'confirmed')";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            stmt.setInt(2, Integer.parseInt(flightId));
            stmt.executeUpdate();

            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        // Redirect to reservation list page (we’ll build that next)
        response.sendRedirect("jsp/viewReservations.jsp");
    }
}
