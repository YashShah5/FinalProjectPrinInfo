package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AdminUserServlet")
public class AdminUserServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> users = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery("SELECT id, username, role FROM users");

            while (rs.next()) {
                String[] user = new String[3];
                user[0] = rs.getString("id");
                user[1] = rs.getString("username");
                user[2] = rs.getString("role");
                users.add(user);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("users", users);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/manageUsers.jsp");
        dispatcher.forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        int userId = Integer.parseInt(request.getParameter("userId"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            if ("delete".equals(action)) {
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM users WHERE id=?");
                stmt.setInt(1, userId);
                stmt.executeUpdate();
                stmt.close();

            } else if ("changeRole".equals(action)) {
                String newRole = request.getParameter("newRole");
                PreparedStatement stmt = conn.prepareStatement("UPDATE users SET role=? WHERE id=?");
                stmt.setString(1, newRole);
                stmt.setInt(2, userId);
                stmt.executeUpdate();
                stmt.close();
            }

            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("AdminUserServlet");
    }
}
