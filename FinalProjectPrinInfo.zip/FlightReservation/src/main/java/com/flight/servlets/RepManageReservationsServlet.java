package com.flight.servlets;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RepManageReservationsServlet")
public class RepManageReservationsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> reservations = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = """
                SELECT r.id, u.username, f.flight_number, r.class_type, r.status
                FROM reservations r
                JOIN users u ON r.user_id = u.id
                JOIN flights f ON r.flight_id = f.id
                ORDER BY r.id DESC
            """;

            Statement stmt = conn.createStatement();
            ResultSet rs = stmt.executeQuery(sql);

            while (rs.next()) {
                String[] row = new String[5];
                row[0] = rs.getString("id");
                row[1] = rs.getString("username");
                row[2] = rs.getString("flight_number");
                row[3] = rs.getString("class_type");
                row[4] = rs.getString("status");
                reservations.add(row);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("reservations", reservations);
        request.getRequestDispatcher("jsp/repReservations.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");
        int reservationId = Integer.parseInt(request.getParameter("reservationId"));

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            if ("cancel".equals(action)) {
                PreparedStatement stmt = conn.prepareStatement("UPDATE reservations SET status='cancelled' WHERE id=?");
                stmt.setInt(1, reservationId);
                stmt.executeUpdate();
                stmt.close();

            } else if ("updateClass".equals(action)) {
                String newClass = request.getParameter("newClass");
                PreparedStatement stmt = conn.prepareStatement("UPDATE reservations SET class_type=? WHERE id=?");
                stmt.setString(1, newClass);
                stmt.setInt(2, reservationId);
                stmt.executeUpdate();
                stmt.close();
            }

            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("RepManageReservationsServlet");
    }
}
