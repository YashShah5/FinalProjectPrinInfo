package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/AdminReservationLookupServlet")
public class AdminReservationLookupServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String searchValue = request.getParameter("searchValue");
        ArrayList<String[]> reservations = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "SELECT r.id, u.username, f.flight_number, f.airline, f.departure_time, r.status " +
                         "FROM reservations r " +
                         "JOIN users u ON r.user_id = u.id " +
                         "JOIN flights f ON r.flight_id = f.id " +
                         "WHERE u.username LIKE ? OR f.flight_number LIKE ?";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, "%" + searchValue + "%");
            stmt.setString(2, "%" + searchValue + "%");

            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] row = new String[6];
                row[0] = rs.getString("id");
                row[1] = rs.getString("username");
                row[2] = rs.getString("flight_number");
                row[3] = rs.getString("airline");
                row[4] = rs.getString("departure_time");
                row[5] = rs.getString("status");
                reservations.add(row);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("searchValue", searchValue);
        request.setAttribute("reservations", reservations);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/adminReservations.jsp");
        dispatcher.forward(request, response);
    }
}
