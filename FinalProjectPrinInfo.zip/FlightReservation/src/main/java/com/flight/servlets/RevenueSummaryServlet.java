package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RevenueSummaryServlet")
public class RevenueSummaryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String query = request.getParameter("query");
        double totalRevenue = 0.0;

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = """
                SELECT SUM(f.price) AS revenue
                FROM reservations r
                JOIN flights f ON r.flight_id = f.id
                JOIN users u ON r.user_id = u.id
                WHERE f.flight_number LIKE ? OR f.airline LIKE ? OR u.username LIKE ?
            """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            for (int i = 1; i <= 3; i++) {
                stmt.setString(i, "%" + query + "%");
            }

            ResultSet rs = stmt.executeQuery();
            if (rs.next()) {
                totalRevenue = rs.getDouble("revenue");
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("query", query);
        request.setAttribute("revenue", totalRevenue);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/revenueSummary.jsp");
        dispatcher.forward(request, response);
    }
}
