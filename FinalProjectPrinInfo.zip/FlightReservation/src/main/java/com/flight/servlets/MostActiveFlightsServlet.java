package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/MostActiveFlightsServlet")
public class MostActiveFlightsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> topFlights = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = """
                SELECT f.flight_number, f.airline, COUNT(r.id) AS tickets_sold
                FROM reservations r
                JOIN flights f ON r.flight_id = f.id
                GROUP BY r.flight_id
                ORDER BY tickets_sold DESC
                LIMIT 10
            """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] row = new String[3];
                row[0] = rs.getString("flight_number");
                row[1] = rs.getString("airline");
                row[2] = rs.getString("tickets_sold");
                topFlights.add(row);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("topFlights", topFlights);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/mostActiveFlights.jsp");
        dispatcher.forward(request, response);
    }
}
