package com.flight.servlets;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/TopFlightsServlet")
public class TopFlightsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1"; // your actual MySQL password

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> topFlights = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = """
                SELECT f.flight_number, f.source_airport, f.destination_airport, COUNT(r.id) AS tickets_sold
                FROM reservations r
                JOIN flights f ON r.flight_id = f.id
                GROUP BY r.flight_id
                ORDER BY tickets_sold DESC
                LIMIT 5
            """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] row = new String[4];
                row[0] = rs.getString("flight_number");
                row[1] = rs.getString("source_airport") + " → " + rs.getString("destination_airport");
                row[2] = String.valueOf(rs.getInt("tickets_sold"));
                row[3] = "View Flight"; // optional for future link
                topFlights.add(row);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("topFlights", topFlights);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/topFlights.jsp");
        dispatcher.forward(request, response);
    }
}
