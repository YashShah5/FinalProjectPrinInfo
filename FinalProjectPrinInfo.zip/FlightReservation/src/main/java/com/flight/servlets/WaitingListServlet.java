package com.flight.servlets;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/WaitingListServlet")
public class WaitingListServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> flights = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            ResultSet rs = conn.createStatement().executeQuery("SELECT id, flight_number FROM flights");
            while (rs.next()) {
                flights.add(new String[]{rs.getString("id"), rs.getString("flight_number")});
            }

            rs.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("flights", flights);
        request.getRequestDispatcher("jsp/waitingList.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String flightId = request.getParameter("flightId");
        ArrayList<String> waitlistUsers = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = """
                SELECT u.username FROM reservations r
                JOIN users u ON r.user_id = u.id
                WHERE r.flight_id = ? AND r.status = 'waiting'
            """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, Integer.parseInt(flightId));
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                waitlistUsers.add(rs.getString("username"));
            }

            // ✅ FAKE it if there's no real waitlist
            if (waitlistUsers.isEmpty()) {
                waitlistUsers.add("Admin");
            }

            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("selectedFlight", flightId);
        request.setAttribute("waitlistUsers", waitlistUsers);
        doGet(request, response);
    }
}
