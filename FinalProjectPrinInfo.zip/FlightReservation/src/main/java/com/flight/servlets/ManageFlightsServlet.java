package com.flight.servlets;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ManageFlightsServlet")
public class ManageFlightsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> flights = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);
            Statement stmt = conn.createStatement();

            ResultSet rs = stmt.executeQuery("SELECT * FROM flights");
            while (rs.next()) {
                String[] flight = new String[6];
                flight[0] = rs.getString("id");
                flight[1] = rs.getString("flight_number");
                flight[2] = rs.getString("airline");
                flight[3] = rs.getString("source_airport");
                flight[4] = rs.getString("destination_airport");
                flight[5] = rs.getString("price");
                flights.add(flight);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("flights", flights);
        request.getRequestDispatcher("jsp/manageFlights.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = request.getParameter("action");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            if ("add".equals(action)) {
                PreparedStatement stmt = conn.prepareStatement(
                    "INSERT INTO flights (flight_number, airline, source_airport, destination_airport, price) VALUES (?, ?, ?, ?, ?)"
                );
                stmt.setString(1, request.getParameter("flightNumber"));
                stmt.setString(2, request.getParameter("airline"));
                stmt.setString(3, request.getParameter("source"));
                stmt.setString(4, request.getParameter("destination"));
                stmt.setDouble(5, Double.parseDouble(request.getParameter("price")));
                stmt.executeUpdate();
                stmt.close();

            } else if ("delete".equals(action)) {
                PreparedStatement stmt = conn.prepareStatement("DELETE FROM flights WHERE id=?");
                stmt.setInt(1, Integer.parseInt(request.getParameter("flightId")));
                stmt.executeUpdate();
                stmt.close();

            } else if ("edit".equals(action)) {
                PreparedStatement stmt = conn.prepareStatement(
                    "UPDATE flights SET flight_number=?, airline=?, source_airport=?, destination_airport=?, price=? WHERE id=?"
                );
                stmt.setString(1, request.getParameter("flightNumber"));
                stmt.setString(2, request.getParameter("airline"));
                stmt.setString(3, request.getParameter("source"));
                stmt.setString(4, request.getParameter("destination"));
                stmt.setDouble(5, Double.parseDouble(request.getParameter("price")));
                stmt.setInt(6, Integer.parseInt(request.getParameter("flightId")));
                stmt.executeUpdate();
                stmt.close();
            }

            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("ManageFlightsServlet");
    }
}
