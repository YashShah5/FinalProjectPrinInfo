package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    // Update these to match your MySQL setup
    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";        // your MySQL username
    String dbPassword = "password1"; // your MySQL password

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        String username = request.getParameter("username");
        String password = request.getParameter("password");

        boolean isValid = false;
        String role = "";

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "SELECT * FROM users WHERE username=? AND password=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, username);
            stmt.setString(2, password);

            ResultSet rs = stmt.executeQuery();

            if (rs.next()) {
                isValid = true;
                role = rs.getString("role");
                request.getSession().setAttribute("userId", rs.getInt("id"));
                request.getSession().setAttribute("role", role);
            }

            rs.close();
            stmt.close();
            conn.close();
        } catch (Exception e) {
            e.printStackTrace();
        }

        if (isValid) {
            response.sendRedirect("jsp/dashboard.jsp"); // we’ll make this next
        } else {
            response.sendRedirect("jsp/login.jsp?error=1");
        }
    }
}
