package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/TopSpenderServlet")
public class TopSpenderServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> topSpenders = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = """
                SELECT u.username, SUM(f.price) AS total_spent
                FROM reservations r
                JOIN users u ON r.user_id = u.id
                JOIN flights f ON r.flight_id = f.id
                GROUP BY r.user_id
                ORDER BY total_spent DESC
                LIMIT 5
            """;

            PreparedStatement stmt = conn.prepareStatement(sql);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] row = new String[2];
                row[0] = rs.getString("username");
                row[1] = rs.getString("total_spent");
                topSpenders.add(row);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("topSpenders", topSpenders);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/topSpender.jsp");
        dispatcher.forward(request, response);
    }
}