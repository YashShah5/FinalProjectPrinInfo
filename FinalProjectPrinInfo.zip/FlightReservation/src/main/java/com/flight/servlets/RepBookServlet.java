package com.flight.servlets;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/RepBookServlet")
public class RepBookServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        ArrayList<String[]> users = new ArrayList<>();
        ArrayList<String[]> flights = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Load users
            ResultSet rsUsers = conn.createStatement().executeQuery("SELECT id, username FROM users WHERE role = 'user'");
            while (rsUsers.next()) {
                users.add(new String[]{rsUsers.getString("id"), rsUsers.getString("username")});
            }

            // Load flights
            ResultSet rsFlights = conn.createStatement().executeQuery("SELECT id, flight_number, airline FROM flights");
            while (rsFlights.next()) {
                flights.add(new String[]{rsFlights.getString("id"), rsFlights.getString("flight_number"), rsFlights.getString("airline")});
            }

            rsUsers.close();
            rsFlights.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("users", users);
        request.setAttribute("flights", flights);
        request.getRequestDispatcher("jsp/repDashboard.jsp").forward(request, response);
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String userId = request.getParameter("userId");
        String flightId = request.getParameter("flightId");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            PreparedStatement stmt = conn.prepareStatement(
                "INSERT INTO reservations (user_id, flight_id, class_type, status) VALUES (?, ?, 'economy', 'confirmed')"
            );
            stmt.setInt(1, Integer.parseInt(userId));
            stmt.setInt(2, Integer.parseInt(flightId));
            stmt.executeUpdate();

            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        response.sendRedirect("RepBookServlet");
    }
}
