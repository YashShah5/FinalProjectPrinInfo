package com.flight.servlets;

import java.io.*;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SearchAirportFlightsServlet")
public class SearchAirportFlightsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String airport = request.getParameter("airport");
        ArrayList<String[]> departing = new ArrayList<>();
        ArrayList<String[]> arriving = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            // Departing flights
            PreparedStatement stmt1 = conn.prepareStatement(
                "SELECT flight_number, airline, destination_airport FROM flights WHERE source_airport LIKE ?"
            );
            stmt1.setString(1, "%" + airport + "%");
            ResultSet rs1 = stmt1.executeQuery();
            while (rs1.next()) {
                departing.add(new String[]{
                    rs1.getString("flight_number"),
                    rs1.getString("airline"),
                    rs1.getString("destination_airport")
                });
            }
            rs1.close();
            stmt1.close();

            // Arriving flights
            PreparedStatement stmt2 = conn.prepareStatement(
                "SELECT flight_number, airline, source_airport FROM flights WHERE destination_airport LIKE ?"
            );
            stmt2.setString(1, "%" + airport + "%");
            ResultSet rs2 = stmt2.executeQuery();
            while (rs2.next()) {
                arriving.add(new String[]{
                    rs2.getString("flight_number"),
                    rs2.getString("airline"),
                    rs2.getString("source_airport")
                });
            }
            rs2.close();
            stmt2.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("airport", airport);
        request.setAttribute("departing", departing);
        request.setAttribute("arriving", arriving);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/airportFlights.jsp");
        dispatcher.forward(request, response);
    }
}
