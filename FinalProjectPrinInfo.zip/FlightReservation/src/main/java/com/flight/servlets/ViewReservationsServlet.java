package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.ArrayList;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/ViewReservationsServlet")
public class ViewReservationsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1"; // your DB password

    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession(false);
        Integer userId = (Integer) session.getAttribute("userId");

        if (userId == null) {
            response.sendRedirect("login.jsp");
            return;
        }

        ArrayList<String[]> reservations = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "SELECT r.id, f.flight_number, f.departure_time, f.arrival_time, f.airline, f.price, r.status " +
                         "FROM reservations r " +
                         "JOIN flights f ON r.flight_id = f.id " +
                         "WHERE r.user_id = ? ORDER BY f.departure_time DESC";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setInt(1, userId);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] res = new String[7];
                res[0] = rs.getString("flight_number");
                res[1] = rs.getString("departure_time");
                res[2] = rs.getString("arrival_time");
                res[3] = rs.getString("airline");
                res[4] = rs.getString("price");
                res[5] = rs.getString("status");
                res[6] = rs.getString("id"); // reservation ID
                reservations.add(res);
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("reservations", reservations);
        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/viewReservations.jsp");
        dispatcher.forward(request, response);
    }
}
