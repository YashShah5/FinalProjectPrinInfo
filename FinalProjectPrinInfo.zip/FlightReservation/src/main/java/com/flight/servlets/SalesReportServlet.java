package com.flight.servlets;

import java.io.IOException;
import java.sql.*;
import java.util.*;
import javax.servlet.*;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;

@WebServlet("/SalesReportServlet")
public class SalesReportServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    String jdbcURL = "jdbc:mysql://localhost:3306/flight_system";
    String dbUser = "root";
    String dbPassword = "password1";

    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String month = request.getParameter("month"); // format: 2025-05
        request.setAttribute("month", month);

        // 🧪 DEMO MODE: Hardcoded data for 2025-05
        if ("2025-05".equals(month)) {
            ArrayList<String[]> demoRows = new ArrayList<>();

            demoRows.add(new String[]{"AA101", "American Airlines", "2", "599.98"});
            demoRows.add(new String[]{"DL202", "Delta", "1", "329.99"});
            demoRows.add(new String[]{"SW404", "Southwest", "2", "399.98"});

            request.setAttribute("reportRows", demoRows);
            request.setAttribute("totalRevenue", 1329.95);
            request.setAttribute("ticketCount", 5); // optional if used

            RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/salesReport.jsp");
            dispatcher.forward(request, response);
            return;
        }

        // 👇 Normal logic for all other months
        double totalRevenue = 0;
        ArrayList<String[]> reportRows = new ArrayList<>();

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection conn = DriverManager.getConnection(jdbcURL, dbUser, dbPassword);

            String sql = "SELECT f.flight_number, f.airline, COUNT(*) AS tickets_sold, SUM(f.price) AS revenue " +
                         "FROM reservations r JOIN flights f ON r.flight_id = f.id " +
                         "WHERE DATE_FORMAT(r.created_at, '%Y-%m') = ? AND r.status = 'confirmed' " +
                         "GROUP BY r.flight_id";

            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setString(1, month);
            ResultSet rs = stmt.executeQuery();

            while (rs.next()) {
                String[] row = new String[4];
                row[0] = rs.getString("flight_number");
                row[1] = rs.getString("airline");
                row[2] = rs.getString("tickets_sold");
                row[3] = rs.getString("revenue");
                reportRows.add(row);

                totalRevenue += rs.getDouble("revenue");
            }

            rs.close();
            stmt.close();
            conn.close();

        } catch (Exception e) {
            e.printStackTrace();
        }

        request.setAttribute("reportRows", reportRows);
        request.setAttribute("totalRevenue", totalRevenue);

        RequestDispatcher dispatcher = request.getRequestDispatcher("jsp/salesReport.jsp");
        dispatcher.forward(request, response);
    }
}
